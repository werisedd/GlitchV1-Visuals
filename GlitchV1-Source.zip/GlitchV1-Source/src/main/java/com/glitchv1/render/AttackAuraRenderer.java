package com.glitchv1.render;

import com.glitchv1.GlitchV1;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Box;
import org.lwjgl.opengl.GL11;

public class AttackAuraRenderer {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    
    public static void render(MatrixStack matrices, Camera camera) {
        if (!GlitchV1.config.attackAura || mc.targetedEntity == null) return;
        if (!(mc.targetedEntity instanceof LivingEntity)) return;
        
        Entity entity = mc.targetedEntity;
        Box box = entity.getBoundingBox()
            .offset(-camera.getPos().x, -camera.getPos().y, -camera.getPos().z)
            .expand(0.05);
        
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableTexture();
        RenderSystem.disableDepthTest();
        RenderSystem.lineWidth(2.0f);
        
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder buffer = tessellator.getBuffer();
        
        // Нижний квадрат
        buffer.begin(GL11.GL_LINE_LOOP, VertexFormats.POSITION_COLOR);
        buffer.vertex(box.minX, box.minY, box.minZ).color(255, 255, 255, 200).next();
        buffer.vertex(box.maxX, box.minY, box.minZ).color(255, 255, 255, 200).next();
        buffer.vertex(box.maxX, box.minY, box.maxZ).color(255, 255, 255, 200).next();
        buffer.vertex(box.minX, box.minY, box.maxZ).color(255, 255, 255, 200).next();
        tessellator.draw();
        
        // Верхний квадрат
        buffer.begin(GL11.GL_LINE_LOOP, VertexFormats.POSITION_COLOR);
        buffer.vertex(box.minX, box.maxY, box.minZ).color(255, 255, 255, 200).next();
        buffer.vertex(box.maxX, box.maxY, box.minZ).color(255, 255, 255, 200).next();
        buffer.vertex(box.maxX, box.maxY, box.maxZ).color(255, 255, 255, 200).next();
        buffer.vertex(box.minX, box.maxY, box.maxZ).color(255, 255, 255, 200).next();
        tessellator.draw();
        
        // Вертикальные рёбра
        buffer.begin(GL11.GL_LINES, VertexFormats.POSITION_COLOR);
        double[][] corners = {
            {box.minX, box.minZ}, {box.maxX, box.minZ},
            {box.maxX, box.maxZ}, {box.minX, box.maxZ}
        };
        for (double[] c : corners) {
            buffer.vertex(c[0], box.minY, c[1]).color(255, 255, 255, 200).next();
            buffer.vertex(c[0], box.maxY, c[1]).color(255, 255, 255, 200).next();
        }
        tessellator.draw();
        
        RenderSystem.enableDepthTest();
        RenderSystem.enableTexture();
        RenderSystem.disableBlend();
    }
}