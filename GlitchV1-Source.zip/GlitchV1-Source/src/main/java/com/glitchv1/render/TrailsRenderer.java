package com.glitchv1.render;

import com.glitchv1.GlitchV1;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

public class TrailsRenderer {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    
    public static void render(MatrixStack matrices, Camera camera) {
        if (!GlitchV1.config.trails || mc.player == null || mc.world == null) return;
        
        Vec3d camPos = camera.getPos();
        Vec3d playerPos = mc.player.getPos().subtract(camPos);
        
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableTexture();
        RenderSystem.disableDepthTest();
        RenderSystem.lineWidth(1.5f);
        
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder buffer = tessellator.getBuffer();
        buffer.begin(GL11.GL_LINES, VertexFormats.POSITION_COLOR);
        
        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player) continue;
            if (player.squaredDistanceTo(mc.player) > 10000) continue;
            
            Vec3d targetPos = player.getPos()
                .add(0, player.getHeight() / 2, 0)
                .subtract(camPos);
            
            buffer.vertex(playerPos.x, playerPos.y, playerPos.z)
                .color(255, 255, 255, 150).next();
            buffer.vertex(targetPos.x, targetPos.y, targetPos.z)
                .color(255, 255, 255, 150).next();
        }
        
        tessellator.draw();
        
        RenderSystem.enableDepthTest();
        RenderSystem.enableTexture();
        RenderSystem.disableBlend();
    }
}