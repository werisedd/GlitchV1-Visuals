package com.glitchv1.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;

public class NoRenderHandler {
    public static void onWorldRender(MatrixStack matrices, Camera camera) {
        AttackAuraRenderer.render(matrices, camera);
        TrailsRenderer.render(matrices, camera);
    }
}