package com.glitchv1.config;

public class ConfigManager {
    public boolean attackAura = true;
    public boolean trails = true;
    public boolean fullbright = true;
    public boolean customTime = false;
    public long customTimeTicks = 6000;
    public boolean noFireOverlay = true;
    public boolean noTotemParticles = true;
    public boolean noBreakParticles = true;
    public boolean noHurtCam = true;
    public float gammaValue = 100.0f;
}