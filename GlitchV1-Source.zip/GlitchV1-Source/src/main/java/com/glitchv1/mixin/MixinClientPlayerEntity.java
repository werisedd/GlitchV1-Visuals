package com.glitchv1.mixin;

import com.glitchv1.GlitchV1;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.particle.ParticleTypes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public class MixinClientPlayerEntity {
    
    @Inject(method = "addParticle", at = @At("HEAD"), cancellable = true)
    private void blockParticles(net.minecraft.particle.ParticleEffect parameters, CallbackInfo ci) {
        if (GlitchV1.config.noTotemParticles && 
            parameters.getType() == ParticleTypes.TOTEM_OF_UNDYING) {
            ci.cancel();
        }
        if (GlitchV1.config.noBreakParticles && 
            parameters.getType() == ParticleTypes.BLOCK) {
            ci.cancel();
        }
    }
}