package com.glitchv1.mixin;

import com.glitchv1.GlitchV1;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class MixinGameRenderer {
    
    @Inject(method = "render", at = @At("HEAD"))
    private void onRender(MatrixStack matrices, float tickDelta, 
                         long startTime, boolean tick, CallbackInfo ci) {
        if (GlitchV1.config.fullbright) {
            net.minecraft.client.MinecraftClient.getInstance()
                .options.gamma = GlitchV1.config.gammaValue;
        }
    }
    
    @Inject(method = "bobView", at = @At("HEAD"), cancellable = true)
    private void noHurtCam(MatrixStack matrices, float f, CallbackInfo ci) {
        if (GlitchV1.config.noHurtCam) {
            ci.cancel();
        }
    }
}